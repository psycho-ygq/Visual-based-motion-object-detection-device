classdef project_APP_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure     matlab.ui.Figure
        TabGroup     matlab.ui.container.TabGroup
        Tab          matlab.ui.container.Tab
        Panel        matlab.ui.container.Panel
        Text         matlab.ui.control.TextArea
        Label_10     matlab.ui.control.Label
        First        matlab.ui.control.TextArea
        Label_9      matlab.ui.control.Label
        TextArea     matlab.ui.control.TextArea
        Label_7      matlab.ui.control.Label
        finish       matlab.ui.control.Button
        FaceTest_3   matlab.ui.control.Label
        MoveButton   matlab.ui.control.Button
        Test5Label   matlab.ui.control.Label
        FaceTest_2   matlab.ui.control.Label
        RoteButton   matlab.ui.control.Button
        Test4Label   matlab.ui.control.Label
        Angle_2      matlab.ui.control.Label
        Test3Label   matlab.ui.control.Label
        Test2Label   matlab.ui.control.Label
        Test1Label   matlab.ui.control.Label
        FaceMark     matlab.ui.control.Label
        Label_6      matlab.ui.control.Label
        FaceTest     matlab.ui.control.Label
        FaceButton   matlab.ui.control.Button
        Angle        matlab.ui.control.Label
        Y            matlab.ui.control.Label
        X            matlab.ui.control.Label
        XYLabel      matlab.ui.control.Label
        Button_3     matlab.ui.control.Button
        Lamp_2       matlab.ui.control.Lamp
        Label_5      matlab.ui.control.Label
        AngleTest    matlab.ui.control.Label
        AngleButton  matlab.ui.control.Button
        OFFLabel     matlab.ui.control.Label
        Label        matlab.ui.control.Label
        Lamp         matlab.ui.control.Lamp
        Tab2         matlab.ui.container.Tab
    end

    
    properties (Access = private)
        COM = 'COM12'
        Boundrate = 9600

        s = serialport('COM29',9600);
        
        data = [0 0 0 0 0 0 0 0 0]
        BeginFlag = 0;
        AngleFlag = 1;
        FaceFlag = 1;
        RoteFlag = 1;
        MoveFlag = 1;
        AX
        AY
    end
    
    methods (Access = private)
        
        function Status_Lamp(app)
            if app.BeginFlag == 0
                app.Lamp.Color = 'r';
                app.OFFLabel.Text = 'OFF';
            else
                app.Lamp.Color = 'g';
                app.OFFLabel.Text = 'ON';
            end
        end
        
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: AngleButton
        function AngleButtonPushed(app, event)
            % 角度修正
            ax_t = 0.0;                 %X轴角度修正
            ay_t = 0.0;                 %Y轴角度修正
            ax_tar = 0.0;
            ay_tar = 0.0;
            xz = 0;

            count_tt = 0;               %修正计时
            
            app.Angle.Text = "开始角度测量，请等待角度校准";
            pause(1)
            while(app.AngleFlag)
                app.data = recievedata(app.s);
            %     D_data = [D_data ; data];
                ax = app.data(7);
                ay = app.data(8);
            
                if abs(ax) < 3 && abs(ay) < 2  && xz == 0
                    count_tt = count_tt + 1;
                else
                    count_tt = 0;
                end
                if count_tt >=30 && xz == 0
                    ax_t = ax - ax_tar;
                    ay_t = ay - ay_tar;
                    count_tt = count_tt - 6;
                end

                ax_r = ax - ax_t;        %测量角度alpha
                ay_r = ay - ay_t ;       %测量角度beta
                
                if abs(ax_r) <= 0.015 && abs(ay_r) <= 0.015 && xz == 0
                    xz = 1;
                    app.Angle.Text = "已完成角度校准";
                elseif  abs(ax_r) > 0.2 && abs(ay_r) >= 0.2 && abs(ax_r) < 1 && abs(ay_r) < 1 
                    xz = 0;
                end
                app.X.Text = num2str(ax_r);
                app.Y.Text = num2str(ay_r);
                pause(0.01);
            end
        end

        % Button pushed function: Button_3
        function Button_3Pushed(app, event)
            if strcmp(app.Button_3.Text,"打开串口")
                fopen(app.s);
                app.Lamp_2.Color = 'g';
                app.Button_3.Text = "关闭串口";
%                 while(strcmp(get(app.s,'Status'),'open'))
                    app.BeginFlag = BeginTest(app.s);

%                     data = recievedata(app.s)
                    app.Status_Lamp
                    pause(0.01)
%                 end
            else 
                delete(app.s);
                if strcmp(app.Button_3.Text,"关闭串口")
                    app.Lamp_2.Color = 'r';
                    app.Button_3.Text = "打开串口";
                end
            end
        end

        % Button pushed function: FaceButton
        function FaceButtonPushed(app, event)
            app.AngleFlag = 0;
            flag = -1;
            
            pia1 = 0;
            pia2 = -90;
%             pia3 = -180;
            pia4 = 90;
            pia5 = 180;
            %      X   |  Y   |  Z
            % A = pia1 | pia1 |  
            % B = pia4 | pia2 |  
            % C = pia5 | pia1 |  
            % D =      | pia4 | pia5
            % E = pia2 | pia1 |  
            % F = pia4 | pia1 |  
            
            delta = 9;
            %物体顶面 -1 为当前顶面 初始化为1
            A = 1;              
            B = 1;
            C = 1;
            D = 1;
            E = 1;
            F = 1;
            
            while(app.FaceFlag)
                app.data = recievedata(app.s);
            %     D_data = [D_data ; data];
                % A
                if abs(app.data(7) - pia1) < delta && abs(app.data(8) - pia1) < delta && app.data(9)~=0
                   if A ~= flag 
                        fprintf("运动物体顶面标记：A\n")
                        fprintf("X:%.3f Y:%.3f Z:%.3f\n",app.data(7),app.data(8),app.data(9))
                        app.FaceMark.Text = "A";
                        A = flag;
                        B = ~flag;
                        D = ~flag;
                        E = ~flag;
                        F = ~flag;
                   end
                end
            
                % B
                if  abs(app.data(8) - pia2) < delta %&& abs(data(7) - pia4) < delta 
                    if B ~= flag
                        fprintf("运动物体顶面标记：B\n")
                        fprintf("X:%.3f Y:%.3f Z:%.3f\n",app.data(7),app.data(8),app.data(9))
                        app.FaceMark.Text = "B";
                        B = flag;
                        A = ~flag;
                        C = ~flag;
                        E = ~flag;
                        F = ~flag;
                    end
                end
                % C 
                if abs(app.data(7) - pia5) < delta && abs(app.data(8) - pia1) < delta
                   if C ~= flag 
                        fprintf("运动物体顶面标记：C\n")
                        fprintf("X:%.3f Y:%.3f Z:%.3f\n",app.data(7),app.data(8),app.data(9))
                        app.FaceMark.Text = "C";
                        C = flag;
                        B = ~flag;
                        D = ~flag;
                        E = ~flag;
                        F = ~flag;
                   end
                end
                % D
                if abs(app.data(8) - pia4) < delta %&& abs(data(9) - pia5) < delta
                    if D ~= flag
                        fprintf("运动物体顶面标记：D\n")
                        fprintf("X:%.3f Y:%.3f Z:%.3f\n",app.data(7),app.data(8),app.data(9))
                        app.FaceMark.Text = "D";
                        D = flag;
                        A = ~flag;
                        C = ~flag;
                        E = ~flag;
                        F = ~flag;
                    end
                end
                % E
                if abs(app.data(7) - pia2) < delta && abs(app.data(8) - pia1) < delta
                   if E ~= flag 
                        fprintf("运动物体顶面标记：E\n")
                        fprintf("X:%.3f Y:%.3f Z:%.3f\n",app.data(7),app.data(8),app.data(9))
                        app.FaceMark.Text = "E";
                        E = flag;
                        A = ~flag;
                        B = ~flag;
                        C = ~flag;
                        D = ~flag;
                   end
                end
                % F
                if abs(app.data(7) - pia4) < delta && abs(app.data(8) - pia1) < delta
                    if F ~= flag
                        fprintf("运动物体顶面标记：F\n")
                        fprintf("X:%.3f Y:%.3f Z:%.3f\n",app.data(7),app.data(8),app.data(9))
                        app.FaceMark.Text = "F";
                        F = flag;
                        A = ~flag;
                        B = ~flag;
                        C = ~flag;
                        D = ~flag;
                    end
                end
            
            end
        end

        % Button pushed function: RoteButton
        function RoteButtonPushed(app, event)
            app.FaceFlag = 0;

            white = imread('F:\桌面文件\text_figure\white.png');
            black = imread('F:\桌面文件\text_figure\black.png');
            white= imresize(white,[300 300]);
            black= imresize(black,[300 300]);
            % 查看适配器
            disp(imaqhwinfo);
            
            % 查看设备及其支持的格式
            info = imaqhwinfo('winvideo');
            
            % 生成对象并同步画面
            obj = videoinput('winvideo',2,'MJPG_640x480');
            h = preview(obj);
            
            temp=-1;
            %生成单个图像
            figure
            while ishandle(h) && app.RoteFlag
            
                A = getsnapshot(obj);
                A = rgb2gray(A);
            
                A (:, 1:84) = [];    %去掉左边界
                A (:, 432:556) = [];  %去掉右边界
                A (1:28,:) = [];     %去掉上边界
                A (428:452,:) = [];     %去掉下边界
            
                A= imresize(A,[640 640]);
                A1 = double(A);
                A2 = 1.5.^(A1*0.070)-1;
                A1 = uint8(A1);
                A2 = uint8(A2);
            
                level = graythresh(A1);  %求取二值化的阈值
                A3 = im2bw(A1, 0.15);   %按阈值进行二值化后的图像，阈值level越低越好
            
                %运用开操作消去噪点
                se = strel('disk',2);
                A4=imopen(A3,se);% 去噪后的图像
                A4=~A4;
            
                %获取连通区域，并进行显示
                % L = bwlabel(openbw,8);
                [L,num] = bwlabel(A4,8);
                A5 = label2rgb(L);
                
                
                I=A4;
                if length(size(I))>2
                    I = rgb2gray(I);
                end
                if ~islogical(I)
                    imBw = im2bw(I);                        %转换为二值化图像
                else
                    imBw = I;
                end
                %imBw = im2bw(I); %转换为二值化图像
                imBw =I;
                imLabel = bwlabel(imBw);                %对各连通域进行标记
                stats = regionprops(imLabel,'Area');    %求各连通域的大小
                area = cat(1,stats.Area);
                index = find(area == max(area));        %求最大连通域的索引
                A6 = ismember(imLabel,index);          %获取最大连通域图像
                
                Ilabel = bwlabel(A6);     %连通区域标记函数
                stat = regionprops(Ilabel,'centroid');%用来度量图像区域属性的函数.常用来统计被标记的区域的面积分布，显示区域总数
                
            %     figure(2)
            %     subplot(221),imshow(A1);  %灰度图像
            %     %subplot(332),imshow(A2);  %指数变化    不用！
            %     subplot(222),imshow(A3);  %二值化后的图像
            %     subplot(223),imshow(A4);  %去噪后的图像
            %     %subplot(335),imshow(A5);  %加上颜色
            %     subplot(224),imshow(A6);
                hold on;
            
                if numel(stat)==1
            %         for x = 1: numel(stat)
            %             plot(stat(x).Centroid(1),stat(x).Centroid(2),'b*');
            %         end %最大联通区域
                
                    stat(1).Centroid(1);stat(1).Centroid(2);
                
                    if stat(1).Centroid(1)>0 && stat(1).Centroid(1) <160
                        if stat(1).Centroid(2)>0 && stat(1).Centroid(2) <160
                            site=12;end
                        if stat(1).Centroid(2)>160 && stat(1).Centroid(2) <320
                            site=8;end
                        if stat(1).Centroid(2)>320 && stat(1).Centroid(2) <480
                            site=4;end
                        if stat(1).Centroid(2)>480 && stat(1).Centroid(2) <640
                            site=0;end
                    end
                    
                    if stat(1).Centroid(1)>160 && stat(1).Centroid(1) <320
                        if stat(1).Centroid(2)>0 && stat(1).Centroid(2) <160
                            site=13;end
                        if stat(1).Centroid(2)>160 && stat(1).Centroid(2) <320
                            site=9;end
                        if stat(1).Centroid(2)>320 && stat(1).Centroid(2) <480
                            site=5;end
                        if stat(1).Centroid(2)>480 && stat(1).Centroid(2) <640
                            site=1;end
                    end
                    
                    if stat(1).Centroid(1)>320 && stat(1).Centroid(1) <480
                        if stat(1).Centroid(2)>0 && stat(1).Centroid(2) <160
                            site=14;end
                        if stat(1).Centroid(2)>160 && stat(1).Centroid(2) <320
                            site=10;end
                        if stat(1).Centroid(2)>320 && stat(1).Centroid(2) <480
                            site=6;end
                        if stat(1).Centroid(2)>480 && stat(1).Centroid(2) <640
                            site=2;end
                    end
                    
                    if stat(1).Centroid(1)>480 && stat(1).Centroid(1) <640
                        if stat(1).Centroid(2)>0 && stat(1).Centroid(2) <160
                            site=15;end
                        if stat(1).Centroid(2)>160 && stat(1).Centroid(2) <320
                            site=11;end
                        if stat(1).Centroid(2)>320 && stat(1).Centroid(2) <480
                            site=7;end
                        if stat(1).Centroid(2)>480 && stat(1).Centroid(2) <640
                            site=3;end
                    end
                
                    if site~=temp
                        fprintf('物体的横坐标为%6.2f,纵坐标为%6.2f,物体位于区域%d。\n',stat(1).Centroid(1),stat(1).Centroid(2),site);
                        app.TextArea.Value = strcat(app.TextArea.Value,strcat(num2str(site),'->'));
                    end
                end
                temp=site;
            
                if site==0
                    site_num=13;
                end
                if site==1
                    site_num=14;
                end
                if site==2
                    site_num=15;
                end
                if site==3
                    site_num=16;
                end
                if site==4
                    site_num=9;
                end
                if site==5
                    site_num=10;
                end
                if site==6
                    site_num=11;
                end
                if site==7
                    site_num=12;
                end
                if site==8
                    site_num=5;
                end
                if site==9
                    site_num=6;
                end
                if site==10
                    site_num=7;
                end
                if site==11
                    site_num=8;
                end
                if site==12
                    site_num=1;
                end
                if site==13
                    site_num=2;
                end
                if site==14
                    site_num=3;
                end
                if site==15
                    site_num=4;
                end
            
                figure(2);
                subplot(441),imshow(white);
                subplot(442),imshow(white);
                subplot(443),imshow(white);
                subplot(444),imshow(white);
                subplot(445),imshow(white);
                subplot(446),imshow(white);
                subplot(447),imshow(white);
                subplot(448),imshow(white);
                subplot(449),imshow(white);
                subplot(4,4,10),imshow(white);
                subplot(4,4,11),imshow(white);
                subplot(4,4,12),imshow(white);
                subplot(4,4,13),imshow(white);
                subplot(4,4,14),imshow(white);
                subplot(4,4,15),imshow(white);
                subplot(4,4,16),imshow(white);
                subplot(4,4,site_num),imshow(black);
                hold on;
            
                drawnow
            end
        end

        % Button pushed function: MoveButton
        function MoveButtonPushed(app, event)
            app.RoteFlag = 0;

            %关闭所以窗口
%             set(groot,'ShowHiddenHandles','on'); c = get(groot,"Children"); delete(c)
            % 查看适配器
            disp(imaqhwinfo)
            
            % 查看设备及其支持的格式
            info = imaqhwinfo('winvideo');
            
            % 生成对象并同步画面
            obj = videoinput('winvideo',2,'MJPG_640x480');
            h = preview(obj);
            
            temp=-1;
            i = 1;
            %生成单个图像
            figure;
            while ishandle(h) && app.MoveFlag
            
                A = getsnapshot(obj);
                A = rgb2gray(A);
            
                A (:, 1:84) = [];    %去掉左边界
                A (:, 432:556) = [];  %去掉右边界
                A (1:28,:) = [];     %去掉上边界
                A (428:452,:) = [];     %去掉下边界
            
                A= imresize(A,[640 640]);
                A1 = double(A);
                A2 = 1.5.^(A1*0.070)-1;
                A1 = uint8(A1);
                A2 = uint8(A2);
            
                level = graythresh(A1);  %求取二值化的阈值
                A3 = im2bw(A1, 0.15);   %按阈值进行二值化后的图像，阈值level越低越好
            
                %运用开操作消去噪点
                se = strel('disk',2);
                A4=imopen(A3,se);% 去噪后的图像
                A4=~A4;
            
                %获取连通区域，并进行显示
                % L = bwlabel(openbw,8);
                [L,num] = bwlabel(A4,8);
                A5 = label2rgb(L);
                
                

                I=A4;
                if length(size(I))>2
                    I = rgb2gray(I);
                end
                if ~islogical(I)
                    imBw = im2bw(I);                        %转换为二值化图像
                else
                 imBw = I;
                end
                %imBw = im2bw(I); %转换为二值化图像
                imBw =I;
                imLabel = bwlabel(imBw);                %对各连通域进行标记
                stats = regionprops(imLabel,'Area');    %求各连通域的大小
                area = cat(1,stats.Area);
                index = find(area == max(area));        %求最大连通域的索引
                A6 = ismember(imLabel,index);          %获取最大连通域图像
                
                Ilabel = bwlabel(A6);     %连通区域标记函数
                stat = regionprops(Ilabel,'centroid');%用来度量图像区域属性的函数.常用来统计被
                                                       %标记的区域的面积分布，显示区域总数
                
                subplot(221),imshow(A1);  %灰度图像
                %subplot(332),imshow(A2);  %指数变化    不用！
                subplot(222),imshow(A3);  %二值化后的图像
                subplot(223),imshow(A4);  %去噪后的图像
                %subplot(335),imshow(A5);  %加上颜色
                
                subplot(224),imshow(A6),hold on;
                if numel(stat)==1
                    for x = 1: numel(stat)
                        plot(stat(x).Centroid(1),stat(x).Centroid(2),'b*');
                    end %最大联通区域
                
                    stat(1).Centroid(1);stat(1).Centroid(2);
                
                    if stat(1).Centroid(1)>0 && stat(1).Centroid(1) <160
                        if stat(1).Centroid(2)>0 && stat(x).Centroid(2) <160
                            site=12;end
                        if stat(1).Centroid(2)>160 && stat(x).Centroid(2) <320
                            site=8;end
                        if stat(1).Centroid(2)>320 && stat(x).Centroid(2) <480
                            site=4;end
                        if stat(1).Centroid(2)>480 && stat(x).Centroid(2) <640
                            site=0;end
                    end
                    
                    if stat(1).Centroid(1)>160 && stat(1).Centroid(1) <320
                        if stat(1).Centroid(2)>0 && stat(x).Centroid(2) <160
                            site=13;end
                        if stat(1).Centroid(2)>160 && stat(x).Centroid(2) <320
                            site=9;end
                        if stat(1).Centroid(2)>320 && stat(x).Centroid(2) <480
                            site=5;end
                        if stat(1).Centroid(2)>480 && stat(x).Centroid(2) <640
                            site=1;end
                    end
                    
                    if stat(1).Centroid(1)>320 && stat(1).Centroid(1) <480
                        if stat(1).Centroid(2)>0 && stat(x).Centroid(2) <160
                            site=14;end
                        if stat(1).Centroid(2)>160 && stat(x).Centroid(2) <320
                            site=10;end
                        if stat(1).Centroid(2)>320 && stat(x).Centroid(2) <480
                            site=6;end
                        if stat(1).Centroid(2)>480 && stat(x).Centroid(2) <640
                            site=2;end
                    end
                    
                    if stat(1).Centroid(1)>480 && stat(1).Centroid(1) <640
                        if stat(1).Centroid(2)>0 && stat(x).Centroid(2) <160
                            site=15;end
                        if stat(1).Centroid(2)>160 && stat(x).Centroid(2) <320
                            site=11;end
                        if stat(1).Centroid(2)>320 && stat(x).Centroid(2) <480
                            site=7;end
                        if stat(1).Centroid(2)>480 && stat(x).Centroid(2) <640
                            site=3;end
                    end
                
                    if site~=temp
                        app.Text.Value = strcat(app.Text.Value,strcat(num2str(site),'->'));
                    end

                    if site~=temp&&temp==-1
                        fprintf('物体的横坐标为%6.2f,纵坐标为%6.2f,物体最初位于区域%d。\n',stat(1).Centroid(1),stat(1).Centroid(2),site);
                            app.First.Value = num2str(site);
                    end
                end
            
                temp=site;
                drawnow;
            end
        end

        % Button pushed function: finish
        function finishButtonPushed(app, event)
            app.MoveFlag = 0;
            set(groot,'ShowHiddenHandles','on'); c = get(groot,"Children"); delete(c)
            delete(app.s)
            delete(app)
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 1091 777];
            app.UIFigure.Name = 'MATLAB App';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [1 1 1076 777];

            % Create Tab
            app.Tab = uitab(app.TabGroup);
            app.Tab.Title = 'Tab';

            % Create Panel
            app.Panel = uipanel(app.Tab);
            app.Panel.Title = 'Panel';
            app.Panel.Position = [1 1 1074 752];

            % Create Lamp
            app.Lamp = uilamp(app.Panel);
            app.Lamp.Position = [109 543 20 20];
            app.Lamp.Color = [1 0 0];

            % Create Label
            app.Label = uilabel(app.Panel);
            app.Label.FontSize = 25;
            app.Label.Position = [140 524 130 60];
            app.Label.Text = '设备状态：';

            % Create OFFLabel
            app.OFFLabel = uilabel(app.Panel);
            app.OFFLabel.FontSize = 25;
            app.OFFLabel.Position = [261 538 75 33];
            app.OFFLabel.Text = 'OFF';

            % Create AngleButton
            app.AngleButton = uibutton(app.Panel, 'push');
            app.AngleButton.ButtonPushedFcn = createCallbackFcn(app, @AngleButtonPushed, true);
            app.AngleButton.Position = [205 462 127 34];
            app.AngleButton.Text = '开始';

            % Create AngleTest
            app.AngleTest = uilabel(app.Panel);
            app.AngleTest.FontSize = 20;
            app.AngleTest.Position = [111 460 105 39];
            app.AngleTest.Text = '角度测量：';

            % Create Label_5
            app.Label_5 = uilabel(app.Panel);
            app.Label_5.HorizontalAlignment = 'right';
            app.Label_5.Position = [105 595 53 22];
            app.Label_5.Text = '连接状态';

            % Create Lamp_2
            app.Lamp_2 = uilamp(app.Panel);
            app.Lamp_2.Position = [173 595 20 20];
            app.Lamp_2.Color = [1 0 0];

            % Create Button_3
            app.Button_3 = uibutton(app.Panel, 'push');
            app.Button_3.ButtonPushedFcn = createCallbackFcn(app, @Button_3Pushed, true);
            app.Button_3.Position = [216 594 100 22];
            app.Button_3.Text = '打开串口';

            % Create XYLabel
            app.XYLabel = uilabel(app.Panel);
            app.XYLabel.FontSize = 20;
            app.XYLabel.Position = [367 466 325 26];
            app.XYLabel.Text = 'X轴角度α：                   Y轴角度β：';

            % Create X
            app.X = uilabel(app.Panel);
            app.X.FontSize = 20;
            app.X.Position = [474 466 93 26];
            app.X.Text = '0.0';

            % Create Y
            app.Y = uilabel(app.Panel);
            app.Y.FontSize = 20;
            app.Y.Position = [680 466 121 26];
            app.Y.Text = '0.0';

            % Create Angle
            app.Angle = uilabel(app.Panel);
            app.Angle.FontSize = 18;
            app.Angle.Position = [118 428 450 23];
            app.Angle.Text = '请等待角度测量校准！';

            % Create FaceButton
            app.FaceButton = uibutton(app.Panel, 'push');
            app.FaceButton.ButtonPushedFcn = createCallbackFcn(app, @FaceButtonPushed, true);
            app.FaceButton.Position = [206 380 127 34];
            app.FaceButton.Text = '开始';

            % Create FaceTest
            app.FaceTest = uilabel(app.Panel);
            app.FaceTest.FontSize = 20;
            app.FaceTest.Position = [112 378 105 39];
            app.FaceTest.Text = '顶面图案：';

            % Create Label_6
            app.Label_6 = uilabel(app.Panel);
            app.Label_6.FontSize = 20;
            app.Label_6.Position = [368 382 185 26];
            app.Label_6.Text = '运动物体顶面标记：';

            % Create FaceMark
            app.FaceMark = uilabel(app.Panel);
            app.FaceMark.FontSize = 20;
            app.FaceMark.Position = [553 382 25 26];
            app.FaceMark.Text = '';

            % Create Test1Label
            app.Test1Label = uilabel(app.Panel);
            app.Test1Label.FontSize = 20;
            app.Test1Label.Position = [48 540 59 26];
            app.Test1Label.Text = 'Test1:';

            % Create Test2Label
            app.Test2Label = uilabel(app.Panel);
            app.Test2Label.FontSize = 20;
            app.Test2Label.Position = [48 466 59 26];
            app.Test2Label.Text = 'Test2:';

            % Create Test3Label
            app.Test3Label = uilabel(app.Panel);
            app.Test3Label.FontSize = 20;
            app.Test3Label.Position = [48 382 59 26];
            app.Test3Label.Text = 'Test3:';

            % Create Angle_2
            app.Angle_2 = uilabel(app.Panel);
            app.Angle_2.FontSize = 18;
            app.Angle_2.Position = [119 502 450 23];
            app.Angle_2.Text = '请将设备水平放置后开始！';

            % Create Test4Label
            app.Test4Label = uilabel(app.Panel);
            app.Test4Label.FontSize = 20;
            app.Test4Label.Position = [49 308 59 26];
            app.Test4Label.Text = 'Test4:';

            % Create RoteButton
            app.RoteButton = uibutton(app.Panel, 'push');
            app.RoteButton.ButtonPushedFcn = createCallbackFcn(app, @RoteButtonPushed, true);
            app.RoteButton.Position = [206 304 127 34];
            app.RoteButton.Text = '开始';

            % Create FaceTest_2
            app.FaceTest_2 = uilabel(app.Panel);
            app.FaceTest_2.FontSize = 20;
            app.FaceTest_2.Position = [113 302 105 39];
            app.FaceTest_2.Text = '方块翻滚：';

            % Create Test5Label
            app.Test5Label = uilabel(app.Panel);
            app.Test5Label.FontSize = 20;
            app.Test5Label.Position = [50 243 59 26];
            app.Test5Label.Text = 'Test5:';

            % Create MoveButton
            app.MoveButton = uibutton(app.Panel, 'push');
            app.MoveButton.ButtonPushedFcn = createCallbackFcn(app, @MoveButtonPushed, true);
            app.MoveButton.Position = [207 239 127 34];
            app.MoveButton.Text = '开始';

            % Create FaceTest_3
            app.FaceTest_3 = uilabel(app.Panel);
            app.FaceTest_3.FontSize = 20;
            app.FaceTest_3.Position = [114 237 105 39];
            app.FaceTest_3.Text = '方块移动：';

            % Create finish
            app.finish = uibutton(app.Panel, 'push');
            app.finish.ButtonPushedFcn = createCallbackFcn(app, @finishButtonPushed, true);
            app.finish.Position = [357 594 100 22];
            app.finish.Text = '结束';

            % Create Label_7
            app.Label_7 = uilabel(app.Panel);
            app.Label_7.FontSize = 20;
            app.Label_7.Position = [370 308 105 26];
            app.Label_7.Text = '方块路径：';

            % Create TextArea
            app.TextArea = uitextarea(app.Panel);
            app.TextArea.FontSize = 20;
            app.TextArea.Position = [474 306 581 31];

            % Create Label_9
            app.Label_9 = uilabel(app.Panel);
            app.Label_9.HorizontalAlignment = 'right';
            app.Label_9.FontSize = 20;
            app.Label_9.Position = [370 245 85 26];
            app.Label_9.Text = '起始位置';

            % Create First
            app.First = uitextarea(app.Panel);
            app.First.FontSize = 20;
            app.First.Position = [470 240 67 33];

            % Create Label_10
            app.Label_10 = uilabel(app.Panel);
            app.Label_10.HorizontalAlignment = 'right';
            app.Label_10.FontSize = 20;
            app.Label_10.Position = [553 245 85 26];
            app.Label_10.Text = '方块路径';

            % Create Text
            app.Text = uitextarea(app.Panel);
            app.Text.FontSize = 20;
            app.Text.Position = [653 237 391 36];

            % Create Tab2
            app.Tab2 = uitab(app.TabGroup);
            app.Tab2.Title = 'Tab2';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = project_APP_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end